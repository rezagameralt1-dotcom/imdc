IMDC Backend Core (Laravel 11 + Sanctum + RBAC)
- Place files accordingly. Follow README steps you already executed on your server.
